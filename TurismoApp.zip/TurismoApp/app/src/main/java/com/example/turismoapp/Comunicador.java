package com.example.turismoapp;

public interface Comunicador {
    public void responder(String datos);
}
