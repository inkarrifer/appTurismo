package com.example.turismoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegistrarUsuarioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_usuario);
    }
}
